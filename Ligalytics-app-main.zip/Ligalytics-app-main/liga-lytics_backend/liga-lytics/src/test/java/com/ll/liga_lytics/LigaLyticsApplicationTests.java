package com.ll.liga_lytics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LigaLyticsApplicationTests {

	@Test
	void contextLoads() {
	}

}
